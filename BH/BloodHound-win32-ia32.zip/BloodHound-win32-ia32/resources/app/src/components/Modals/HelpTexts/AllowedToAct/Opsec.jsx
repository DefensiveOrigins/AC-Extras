const Opsec = () => {
    let text = `To execute this attack, the Rubeus C# assembly needs to be executed on some system with the ability to send/receive traffic in the domain.`;
    return { __html: text };
};

export default Opsec;
