const References = () => {
    let text = `<a href="https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadgroup">https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadgroup</a>
    <a href="https://docs.microsoft.com/en-us/powershell/module/azuread/add-azureadgroupmember?view=azureadps-2.0-preview">https://docs.microsoft.com/en-us/powershell/module/azuread/add-azureadgroupmember?view=azureadps-2.0-preview</a>`;
    return { __html: text };
};

export default References;
