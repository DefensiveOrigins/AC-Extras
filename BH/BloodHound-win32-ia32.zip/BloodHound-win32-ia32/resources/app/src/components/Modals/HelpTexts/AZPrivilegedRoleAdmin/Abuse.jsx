import { typeFormat } from '../Formatter';
const Abuse = (sourceName, sourceType, targetName, targetType) => {
    let text = `Activate the Global Admin role for yourself or for another user using PowerZure or PowerShell.`;
    return { __html: text };
};

export default Abuse;