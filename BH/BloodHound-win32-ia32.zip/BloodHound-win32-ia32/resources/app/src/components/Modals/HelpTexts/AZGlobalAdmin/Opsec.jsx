const Opsec = () => {
    let text = `This depends on exactly what you do, but in general Azure will log each abuse action.`;
    return { __html: text };
};

export default Opsec;
