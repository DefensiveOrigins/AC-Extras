import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The ability to change another user’s password without knowing their current password`;
    return { __html: text };
};

export default General;
