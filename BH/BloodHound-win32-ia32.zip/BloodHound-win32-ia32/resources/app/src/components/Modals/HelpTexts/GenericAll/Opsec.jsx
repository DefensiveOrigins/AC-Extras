const Opsec = () => {
    let text = `This depends on the target object and how to take advantage of this privilege. Opsec considerations for each abuse primitive are documented on the specific abuse edges and on the BloodHound wiki.`;
    return { __html: text };
};

export default Opsec;
