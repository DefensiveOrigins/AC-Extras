import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The ability to read secrets from key vaults`;
    return { __html: text };
};

export default General;
