const References = () => {
    let text = `<a href="http://www.harmj0y.net/blog/redteaming/the-trustpocalypse/">http://www.harmj0y.net/blog/redteaming/the-trustpocalypse/</a>
    <a href="http://www.harmj0y.net/blog/redteaming/a-guide-to-attacking-domain-trusts/">http://www.harmj0y.net/blog/redteaming/a-guide-to-attacking-domain-trusts/</a>
    <a href="https://adsecurity.org/?p=1772">https://adsecurity.org/?p=1772</a>
    <a href="https://adsecurity.org/?tag=sidhistory">https://adsecurity.org/?tag=sidhistory</a>
    <a href="https://attack.mitre.org/techniques/T1178/">https://attack.mitre.org/techniques/T1178/</a>
    <a href="https://dirkjanm.io/active-directory-forest-trusts-part-one-how-does-sid-filtering-work/">https://dirkjanm.io/active-directory-forest-trusts-part-one-how-does-sid-filtering-work/</a>`;
    return { __html: text };
};

export default References;
