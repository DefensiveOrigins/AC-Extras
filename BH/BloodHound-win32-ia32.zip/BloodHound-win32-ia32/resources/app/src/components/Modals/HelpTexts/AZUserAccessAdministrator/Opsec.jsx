const Opsec = () => {
    let text = `Azure will log any role activation event for any object type.`;
    return { __html: text };
};

export default Opsec;