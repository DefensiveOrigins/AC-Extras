const References = () => {
    let text = ` <a href="https://blog.netspi.com/azure-automation-accounts-key-stores/">https://blog.netspi.com/azure-automation-accounts-key-stores/</a>
    <a href="https://powerzure.readthedocs.io/en/latest/Functions/operational.html#export-azurekeyvaultcontent">https://powerzure.readthedocs.io/en/latest/Functions/operational.html#export-azurekeyvaultcontent</a>`;
    return { __html: text };
};

export default References;
