const References = () => {
    let text = `<a href="https://blog.netspi.com/running-powershell-scripts-on-azure-vms/">https://blog.netspi.com/running-powershell-scripts-on-azure-vms/</a>`;
    return { __html: text };
};

export default References;
