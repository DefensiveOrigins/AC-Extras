import { typeFormat } from '../Formatter';
const Abuse = (sourceName, sourceType, targetName, targetType) => {
    let text = `Everything a Contributor can do, with the addition of assigning rights to resources. `;
    return { __html: text };
};

export default Abuse;
